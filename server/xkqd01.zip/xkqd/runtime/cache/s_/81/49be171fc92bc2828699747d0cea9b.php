<?php
//000000028800
 exit();?>
a:7:{s:2:"id";i:1;s:8:"username";s:6:"张三";s:5:"phone";s:11:"13712345678";s:8:"password";s:32:"96e79218965eb72c92a549dd5a330112";s:8:"add_time";i:1510110021;s:5:"state";i:1;s:4:"role";i:1;}