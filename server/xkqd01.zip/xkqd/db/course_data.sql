/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50635
 Source Host           : 127.0.0.1
 Source Database       : course_data

 Target Server Type    : MySQL
 Target Server Version : 50635
 File Encoding         : utf-8

 Date: 11/08/2017 19:12:04 PM
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `t_api_name`
-- ----------------------------
DROP TABLE IF EXISTS `t_api_name`;
CREATE TABLE `t_api_name` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `api_name` varchar(100) NOT NULL COMMENT '接口名称',
  `name` varchar(100) NOT NULL COMMENT '名称',
  `state` tinyint(4) NOT NULL COMMENT '1正常，2禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `t_lectures`
-- ----------------------------
DROP TABLE IF EXISTS `t_lectures`;
CREATE TABLE `t_lectures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lecture_name` varchar(100) NOT NULL COMMENT '课程名称',
  `add_time` bigint(13) NOT NULL COMMENT '添加时间',
  `lecture_introduction` text NOT NULL COMMENT '简介',
  `user_id` varchar(36) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1正常，-1删除',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `lecture_name` (`lecture_name`),
  KEY `add_time` (`add_time`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `t_lectures`
-- ----------------------------
BEGIN;
INSERT INTO `t_lectures` VALUES ('1', '语文', '1510120690', '文言文', '1', '1'), ('2', '1', '1510128963', '11', '11', '1'), ('3', '2', '1510128969', '22', '11', '1'), ('4', '3', '1510130525', '3333', '11', '1'), ('5', '4', '1510130545', '444', '11', '1'), ('6', '5', '1510135566', '55', '11', '1'), ('7', '6', '1510135618', '66', '11', '1'), ('8', '7', '1510135859', '77', '11', '1'), ('9', '8', '1510136248', '8', '11', '1');
COMMIT;

-- ----------------------------
--  Table structure for `t_release_lectures`
-- ----------------------------
DROP TABLE IF EXISTS `t_release_lectures`;
CREATE TABLE `t_release_lectures` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT '用户id',
  `lectures_id` int(10) unsigned NOT NULL COMMENT '课程id',
  `room` varchar(255) NOT NULL COMMENT '教室地址',
  `add_time` bigint(13) NOT NULL COMMENT '添加时间',
  `schooltime` bigint(13) NOT NULL COMMENT '上课时间',
  `start_sign_time` bigint(13) NOT NULL COMMENT '开始签到时间',
  `end_sign_time` bigint(13) NOT NULL COMMENT '结束签到时间',
  `signcode` varchar(50) NOT NULL COMMENT '签到码',
  `qrcode` varchar(36) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1正常-1删除',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_id` (`user_id`),
  KEY `lectures_id` (`lectures_id`),
  KEY `add_time` (`add_time`),
  KEY `schooltime` (`schooltime`),
  KEY `start_sign_time` (`start_sign_time`),
  KEY `end_sign_time` (`end_sign_time`),
  KEY `signcode` (`signcode`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `t_release_lectures`
-- ----------------------------
BEGIN;
INSERT INTO `t_release_lectures` VALUES ('1', '1', '1', '505教师', '1510128453', '1510145849', '123', '123', '618143', 'ac9b40fa-c465-11e7-8b63-4554d3295428', '1');
COMMIT;

-- ----------------------------
--  Table structure for `t_sign_log`
-- ----------------------------
DROP TABLE IF EXISTS `t_sign_log`;
CREATE TABLE `t_sign_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `add_time` bigint(20) NOT NULL COMMENT '签到时间',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `release_lectures_id` int(11) NOT NULL COMMENT '发布的课程id',
  `longitude` decimal(9,5) NOT NULL DEFAULT '0.00000' COMMENT '经度',
  `latitude` decimal(9,5) NOT NULL DEFAULT '0.00000' COMMENT '纬度',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '签到地址',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `user_id` (`user_id`),
  KEY `release_lectures_id` (`release_lectures_id`),
  KEY `add_time` (`add_time`),
  KEY `longitude` (`longitude`),
  KEY `latitude` (`latitude`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `t_sign_log`
-- ----------------------------
BEGIN;
INSERT INTO `t_sign_log` VALUES ('3', '1510132014', '10', '1', '0.00000', '0.00000', ''), ('4', '1510132056', '10', '1', '0.00000', '0.00000', ''), ('6', '1510132662', '10', '1', '0.00000', '0.00000', '');
COMMIT;

-- ----------------------------
--  Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT '姓名',
  `phone` varchar(50) NOT NULL COMMENT '手机号',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `add_time` bigint(13) NOT NULL COMMENT '添加时间',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1删除，0初始，1正常，2禁用）',
  `role` tinyint(4) NOT NULL COMMENT '1老师，2学生',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `username` (`username`),
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `t_user`
-- ----------------------------
BEGIN;
INSERT INTO `t_user` VALUES ('1', '张三', '13712345678', '96e79218965eb72c92a549dd5a330112', '1510110021', '1', '1'), ('2', 'Name', 'Account', '96e79218965eb72c92a549dd5a330112', '1510117796', '1', '2'), ('7', '1', '1', '96e79218965eb72c92a549dd5a330112', '1510121750', '1', '2'), ('8', '1', '12', '96e79218965eb72c92a549dd5a330112', '1510123745', '1', '2'), ('9', '3', '3', '1a100d2c0dab19c4430e7d73762b3423', '1510123758', '1', '2'), ('10', '4', '4', '96e79218965eb72c92a549dd5a330112', '1510123812', '1', '2'), ('11', 'T', 'T', '96e79218965eb72c92a549dd5a330112', '1510126203', '1', '1');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
