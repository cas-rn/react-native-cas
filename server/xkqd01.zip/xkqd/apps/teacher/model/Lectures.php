<?php

namespace app\teacher\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//课程
class Lectures extends Model
{

    //添加课程
    public function add()
    {

        //验证规则
        $rule = [
            'lecture_name' => 'require',
            'lecture_introduction' => 'require',
            'user_token' => 'require',
        ];
        //提示信息
        $msg = [
            'lecture_name.require' => '课程名称不能为空',
            'lecture_introduction.require' => '简介不能为空',
            'user_token.require' => '用户token不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //获取用户信息
        $user_info = cache(input('param.user_token'));

        $add['lecture_name'] = input('param.lecture_name');
        $add['lecture_introduction'] = input('param.lecture_introduction');
        $add['user_id'] = $user_info['id'];
        $add['add_time'] = time();

        $id = Db::table('t_lectures')->insert($add);

        if ($id) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
        } else {
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '添加失败';
        }

        return $fanhui;
    }


    //获取课程列表
    public function getlist(){
        //获取用户信息
        $user_info = cache(input('param.user_token'));

        $where['state']=1;
        $where['user_id']=$user_info['id'];

        $data = Db::table('t_lectures')
            ->where($where)
            ->field('id,lecture_name,lecture_introduction')
            ->order('add_time desc')
            ->page(getpage())
            ->select();

        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['list']=$data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;
    }

    //删除课程
    public function del(){

    }


}
