<?php

namespace app\home\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//注册
class Register extends Model
{

    public function index()
    {
        //验证规则
        $rule = [
            'username' => 'require',
            'phone' => 'require',
            'password' => 'require',
            'role' => 'require',
        ];
        //提示信息
        $msg = [
            'username.require' => '用户名不能为空',
            'phone.require' => '手机号不能为空',
            'password.require' => '密码不能为空',
            'role.require' => '角色不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //判断是否已经注册

        $where['state']=array('neq','-1');
        $where['phone']=input('param.phone');
        $is_user=Db::table('t_user')
            ->where($where)
            ->field('id')
            ->find();
        if(!empty($is_user)){
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = '手机号已经存在';
            return $fanhui;
            exit;
        }


        $add['username'] = input('param.username');
        $add['phone'] = input('param.phone');
        $add['password'] = md5(input('param.password'));
        $add['role'] = input('param.role');
        $add['add_time'] = time();

        $id = Db::table('t_user')->insert($add);

        if ($id) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
        } else {
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '注册失败';
        }

        return $fanhui;
    }

}
