<?php

namespace app\index\controller;

header("Access-Control-Allow-Origin:*");

use think\Controller;
use think\Request;
use think\Db;
class Index extends Controller{
    

    //入口，判断api内容与路由
    public function index() {

//        sleep(2);
        $api_name = input('param.api_name');
        //没有api_name显示页面
        if (empty($api_name)) {
            //跳转登录页面
            echo "选课签到系统接口";
            exit;
        }

        //判断用户是否登录
        $p_api_name=array(
            'home.register.index',
            'home.login.index',
        );

        if(!in_array($api_name,$p_api_name)){

            //获取用户信息
            $user_info = cache(input('param.user_token'));
            if(empty($user_info)){
                $fanhui['code'] = 40001;
                $fanhui['error_msg'] = '登录过期，请重新登录';
                $fanhui['api_name'] = $api_name;
                return json($fanhui);
            }

        }


        //分解api_name
        $apiname = explode(".", strtolower($api_name));



        //调用具体方法
        $app=$apiname[0];                  //应用
        $model=ucfirst($apiname[1]);       //模型（模块）
        $fun=$apiname[2];         //方法

        $fanhui = model($app.'/' . $model)->$fun();
        $fanhui['api_name'] = $api_name;

        return json($fanhui);
    }

}
