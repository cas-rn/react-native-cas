<?php

namespace app\student\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//发布的课程
class Release extends Model
{


    //获取发布的课程列表
    public function getlist()
    {

        //获取用户信息
        $user_info = cache(input('param.user_token'));
        $where['t_release_lectures.state']=1;
        $where['t_release_lectures.schooltime']=array('gt',time());

        $data = Db::table('t_release_lectures')
            ->join('t_lectures', 't_lectures.id=t_release_lectures.lectures_id')
            ->join('t_user', 't_user.id=t_release_lectures.user_id')

            ->where($where)
            ->field('t_release_lectures.id,
            t_release_lectures.room,
            t_release_lectures.room,
            t_release_lectures.schooltime,
            t_release_lectures.start_sign_time,
            t_release_lectures.end_sign_time,
            t_lectures.lecture_name,
            t_lectures.lecture_introduction,
            t_user.username
            ')
            ->order('t_release_lectures.schooltime asc')
            ->page(getpage())
            ->select();
        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['list'] = $data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;
    }


}
