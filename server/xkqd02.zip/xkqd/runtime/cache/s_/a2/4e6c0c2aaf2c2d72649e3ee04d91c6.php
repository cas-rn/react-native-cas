<?php
//000000028800
 exit();?>
a:4:{s:2:"id";i:2;s:8:"username";s:4:"Name";s:5:"phone";s:7:"Account";s:4:"role";i:2;}