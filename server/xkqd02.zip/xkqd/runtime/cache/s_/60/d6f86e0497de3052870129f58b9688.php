<?php
//000000000000
 exit();?>
a:4:{s:2:"id";i:11;s:8:"username";s:1:"T";s:5:"phone";s:1:"T";s:4:"role";i:1;}