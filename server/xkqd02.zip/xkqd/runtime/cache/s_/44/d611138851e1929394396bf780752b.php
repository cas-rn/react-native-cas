<?php
//000000028800
 exit();?>
a:4:{s:2:"id";i:10;s:8:"username";s:1:"4";s:5:"phone";s:1:"4";s:4:"role";i:2;}