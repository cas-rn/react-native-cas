<?php

namespace app\home\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//登录
class Login extends Model
{

    //登录
    public function index()
    {
        //验证规则
        $rule = [
            'phone' => 'require',
            'password' => 'require',
        ];
        //提示信息
        $msg = [
            'phone.require' => '手机号不能为空',
            'password.require' => '密码不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        $where['state']=1;
        $where['phone']=input('param.phone');
        $where['password']= md5(input('param.password'));


        $user_info= Db::table('t_user')
            ->where($where)
            ->field('id,username,phone,role')
            ->find();


        $user_token=md5($where['phone'].time());

        if(!empty($user_info)){
            //存入缓存
            cache($user_token,$user_info);
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['user_token']=$user_token;
            $fanhui['response']['user_info']=$user_info;
        }else{
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '账号或密码错误';
        }

        return $fanhui;
    }

    //修改密码
    public function uppassword(){
        //获取用户信息
        $user_info = cache(input('param.user_token'));
        //验证规则
        $rule = [
            'password' => 'require',
            'newpassword' => 'require',
        ];
        //提示信息
        $msg = [
            'password.require' => '原密码不能为空',
            'newpassword.require' => '新密码不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //判断原密码
        $where['state']=1;
        $where['phone']=$user_info['phone'];
        $where['password']= md5(input('param.password'));

        $user_info= Db::table('t_user')
            ->where($where)
            ->field('id,username,phone,role')
            ->find();


        if(empty($user_info)){
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = '原密码错误';
            return $fanhui;
            exit;
        }

        //修改签到码
        $uwhere['id'] = $user_info['id'];
        $update['password']= md5(input('param.newpassword'));
        $id=Db::table('t_user')->where($uwhere)->update($update);

        if ($id) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
        } else {
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '密码修改失败';
        }

        return $fanhui;
    }


}
