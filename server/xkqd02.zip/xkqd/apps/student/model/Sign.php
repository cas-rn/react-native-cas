<?php

namespace app\student\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//签到
class Sign extends Model
{

    //签到
    public function scanning()
    {
        //验证规则
        $rule = [
            'qrcode' => 'require',
        ];
        //提示信息
        $msg = [
            'qrcode.require' => '二维码信息不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //获取用户信息
        $user_info = cache(input('param.user_token'));

        //查询发布的课程id
        $release_lectures_data_where['qrcode'] = input('param.qrcode');
        $release_lectures_data = Db::table('t_release_lectures')
            ->where($release_lectures_data_where)
            ->field('id')
            ->find();

        //记录签到信息记录
        $add['release_lectures_id'] = $release_lectures_data['id'];
        $add['user_id'] = $user_info['id'];
        $add['add_time'] = time();
        $add['longitude'] = input('param.longitude');
        $add['latitude'] = input('param.latitude');
        $add['address'] = input('param.address');


        // 启动事务
        Db::startTrans();
        try {

            //添加扫描记录信息
            Db::table('t_sign_log')->insert($add);

            //修改签到码
            $where['id'] = $add['release_lectures_id'];
            $update['signcode'] = rand(100000, 999999);
            $update['qrcode'] = get_mysql_uuid();
            Db::table('t_release_lectures')->where($where)->update($update);

            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '扫码签到失败';
            return $fanhui;
            exit;
        }

        $fanhui['code'] = 0;
        $fanhui['error_msg'] = 'ok';
        $fanhui['response'] = $update;

        return $fanhui;
    }

    //验证码签到
    public function verification()
    {
        //验证规则
        $rule = [
            'signcode' => 'require',
            'release_lectures_id' => 'require',
        ];
        //提示信息
        $msg = [
            'signcode.require' => '签到验证码不能为空',
            'release_lectures_id.require' => '发布的课程id不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //获取用户信息
        $user_info = cache(input('param.user_token'));

        //记录签到信息记录
        $add['release_lectures_id'] = input('param.release_lectures_id');
        $add['user_id'] = $user_info['id'];
        $add['add_time'] = time();
        $add['longitude'] = input('param.longitude');
        $add['latitude'] = input('param.latitude');
        $add['address'] = input('param.address');


        $qd_where['id']=input('param.release_lectures_id');
        $qd_where['signcode']=input('param.signcode');

        $release_lectures_id=Db::table('t_release_lectures')
            ->where($qd_where)
            ->field('id')
            ->find($add);

        if(empty($release_lectures_id)){
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '签到验证码错误';
            return $fanhui;
            exit;
        }

        // 启动事务
        Db::startTrans();
        try {

            //添加扫描记录信息
            Db::table('t_sign_log')->insert($add);

            //修改签到码
            $where['id'] = $add['release_lectures_id'];
            $update['signcode'] = rand(100000, 999999);
            $update['qrcode'] = get_mysql_uuid();
            Db::table('t_release_lectures')->where($where)->update($update);

            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '扫码签到失败';
            return $fanhui;
            exit;
        }

        $fanhui['code'] = 0;
        $fanhui['error_msg'] = 'ok';
        $fanhui['response'] = $update;

        return $fanhui;


    }

    //签到记录
    public function singlog(){
        //获取用户信息
        $user_info = cache(input('param.user_token'));

        $where['t_sign_log.user_id'] = $user_info['id'];

        $data = Db::table('t_sign_log')
            ->join('t_release_lectures', 't_release_lectures.id=t_sign_log.release_lectures_id')
            ->join('t_lectures', 't_lectures.id=t_release_lectures.lectures_id')
            ->join('t_user', 't_user.id=t_release_lectures.user_id')

            ->where($where)
            ->field('t_sign_log.id,
            t_release_lectures.room,
            t_release_lectures.room,
            t_release_lectures.schooltime,
            t_release_lectures.start_sign_time,
            t_release_lectures.end_sign_time,
            t_sign_log.address,
            t_lectures.lecture_name,
            t_lectures.lecture_introduction,
            t_user.username
            ')
            ->order('t_sign_log.add_time desc')
            ->page(getpage())
            ->select();

        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['list'] = $data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;

    }

}
