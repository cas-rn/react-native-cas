<?php

// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------
// 应用公共文件
//vendor('wechat.WeChat');
//require('./vendor/wechat/WeChat.php');
use think\Db;


//guid
function create_guid() {
    $charid = strtoupper(md5(uniqid(mt_rand(), true)));
    $hyphen = chr(45);// "-"
    $uuid = chr(123)// "{"
    .substr($charid, 0, 8).$hyphen
    .substr($charid, 8, 4).$hyphen
    .substr($charid,12, 4).$hyphen
    .substr($charid,16, 4).$hyphen
    .substr($charid,20,12)
    .chr(125);// "}"
    return $uuid;
}

/**
 * 获取树形结构
 * $subset  子集字段名     默认subset
 * $notid   不需要显示id   默认显示
 */
function get_tree($data='', $pid='' ,$id_name='id',$pid_name='pid',$subset='subset',$notid=0){
    $tree = array();
    foreach($data as $k => $v)
    {
       if($v[$pid_name] == $pid)
       {         
        //父亲找到儿子
        $v[$subset] = get_tree($data, $v[$id_name],$id_name,$pid_name,$subset,$notid);
        //清除id
        if($notid){
            unset($v[$id_name]);
            unset($v[$pid_name]);
        }
        //清除空子集
        if(empty($v[$subset])){
            unset($v[$subset]);
        }
        $tree[] = $v;
       }  
    }
    return $tree;
}


//获取分页
function getpage(){
    //请求页数小于默认页数
    if(input('param.pagesize')<config('pagesize') and is_numeric(input('param.pagesize'))){
        $pagesize=input('param.pagesize');
    }else{
        $pagesize=config('pagesize');
    }
    //请求页数
    if(is_numeric(input('param.page'))){
        $page=input('param.page');
    }else{
        $page=1;
    }

    return $page.','.$pagesize;
}

//popt请求
function http_postData($url, $data=[], $header='') {
    $ch = curl_init();
    $timeout = 300;
    //$header = 'Content-type: text/json';//定义content-type为json
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //设置是否返回信息
    if ($header) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);//设置HTTP头
    } else {
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    }
    $handles = curl_exec($ch);
    if (curl_errno($ch)) {//出错则显示错误信息
        // return curl_error($ch);
    }
    curl_close($ch);
    return $handles;
}

//获取MySQLuudi
function get_mysql_uuid(){
    $mysql_uuid=Db::query('select uuid() as uuid;');
    return $mysql_uuid[0]['uuid'];
}


