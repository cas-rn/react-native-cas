<?php

namespace app\teacher\model;

use think\Model;
use think\Request;
use think\Db;
use \think\Validate;

//发布的课程
class Release extends Model
{

    //发布课程
    public function add()
    {
        //验证规则
        $rule = [
            'lectures_id' => 'require',
            'room' => 'require',
            'schooltime' => 'require',
            'start_sign_time' => 'require',
            'end_sign_time' => 'require',
        ];
        //提示信息
        $msg = [
            'lectures_id.require' => '课程id不能为空',
            'room.require' => '上课地址不能为空',
            'schooltime.require' => '上课时间不能为空',
            'start_sign_time.require' => '开始签到时间不能为空',
            'end_sign_time.require' => '结束签到时间不能为空',
        ];

        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        //获取用户信息
        $user_info = cache(input('param.user_token'));

        $add['lectures_id'] = input('param.lectures_id');
        $add['room'] = input('param.room');
        $add['schooltime'] = input('param.schooltime');
        $add['start_sign_time'] = input('param.start_sign_time');
        $add['end_sign_time'] = input('param.end_sign_time');
        $add['user_id'] = $user_info['id'];
        $add['add_time'] = time();
        $add['signcode'] = rand(100000, 999999);
        $add['qrcode'] = get_mysql_uuid();

        $id = Db::table('t_release_lectures')->insert($add);

        if ($id) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
        } else {
            $fanhui['code'] = 10001;
            $fanhui['error_msg'] = '添加失败';
        }
        return $fanhui;
    }


    //获取发布的课程列表
    public function getlist()
    {

        //获取用户信息
        $user_info = cache(input('param.user_token'));

        $where['t_release_lectures.state'] = 1;
        $where['t_release_lectures.user_id'] = $user_info['id'];

        $data = Db::table('t_release_lectures')
            ->join('t_lectures', 't_lectures.id=t_release_lectures.lectures_id')
            ->where($where)
            ->field('t_release_lectures.id,
            t_lectures.lecture_name,
            t_lectures.lecture_introduction,
            t_release_lectures.room,
            t_release_lectures.schooltime,
            t_release_lectures.qrcode,
            t_release_lectures.signcode
            ')
            ->order('t_release_lectures.add_time desc')
            ->page(getpage())
            ->select();

        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['list'] = $data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;
    }

    //签到记录
    public function signlog()
    {
        //验证规则
        $rule = [
            'release_lectures_id' => 'require',
        ];
        //提示信息
        $msg = [
            'release_lectures_id.require' => '发布的课程id不能为空',
        ];
        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }


        $where['t_sign_log.release_lectures_id'] = input('param.release_lectures_id');

        $data = Db::table('t_sign_log')
            ->join('t_user', 't_user.id=t_sign_log.user_id')
            ->where($where)
            ->field('
            t_sign_log.id,
            t_sign_log.add_time,
            t_sign_log.longitude,
            t_sign_log.latitude,
            t_sign_log.address,
            t_user.username
            ')
            ->order('t_sign_log.add_time desc')
            ->page(getpage())
            ->select();

        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response']['list'] = $data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;


    }


    //获取验证信息
    public function getsign()
    {
        //验证规则
        $rule = [
            'release_lectures_id' => 'require',
        ];
        //提示信息
        $msg = [
            'release_lectures_id.require' => '发布的课程id不能为空',
        ];
        //验证数据
        $validate = new Validate($rule, $msg);
        if (!$validate->check(input('param.'))) {
            //错误信息
            $fanhui['code'] = 40010;
            $fanhui['error_msg'] = $validate->getError();
            return $fanhui;
            exit;
        }

        $where['t_release_lectures.id'] = input('param.release_lectures_id');

        $data = Db::table('t_release_lectures')
            ->where($where)
            ->field('id,signcode,qrcode')
            ->find();

        if (!empty($data)) {
            $fanhui['code'] = 0;
            $fanhui['error_msg'] = 'ok';
            $fanhui['response'] = $data;
        } else {
            $fanhui['code'] = 20001;
            $fanhui['error_msg'] = '无数据';
        }

        return $fanhui;

    }

}
